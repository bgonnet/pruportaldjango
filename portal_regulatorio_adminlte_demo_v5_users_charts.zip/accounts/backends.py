import os
import uuid
import datetime
import requests
from django.contrib.auth.models import User

from .models import PortalUserProfile

def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default)

class MicroserviceBackend:
    def authenticate(self, request, username=None, password=None, **kwargs):
        if not username or not password:
            return None

        url = _env("MS_LOGIN_URL")
        if not url:
            return None

        headers = {
            "country": _env("MS_COUNTRY", "EC"),
            "lang": _env("MS_LANG", "es"),
            "entity": _env("MS_ENTITY", "OTECEL"),
            "system": _env("MS_SYSTEM", "RPA"),
            "subsystem": _env("MS_SUBSYSTEM", "EPCXXX"),
            "originator": _env("MS_ORIGINATOR", "ms-gateway-generic-portal-huawei"),
            "userId": _env("MS_USERID", "gateway"),
            "operation": "login",
            "destination": _env("MS_DESTINATION", "environment-ms"),
            "execId": str(uuid.uuid4()),
            "msgId": str(uuid.uuid4()),
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "msgType": "REQUEST",
            "Authorization": _env("MS_AUTH_BASIC"),
            "Content-Type": "application/json",
            "pid": str(uuid.uuid4()),
        }

        payload = {"user": username, "password": password, "ip": ""}

        verify_ssl = _env("MS_VERIFY_SSL", "1") == "1"
        timeout = int(_env("MS_TIMEOUT", "15"))

        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=timeout, verify=verify_ssl)
            resp.raise_for_status()
            data = resp.json()
        except Exception:
            return None

        status = (data.get("status") or "").upper()
        if status not in ("A", "ACTIVO", "ACTIVE"):
            return None

        user, created = User.objects.get_or_create(username=username)

        # Si el usuario existe y está deshabilitado localmente, bloquear el login
        if not created and not user.is_active:
            return None

        # Para usuarios nuevos: habilitar por defecto
        if created:
            user.is_active = True
            user.set_unusable_password()

        admin_users = {u.strip() for u in _env("ADMIN_USERS", "").split(",") if u.strip()}
        admin_role_codes = {c.strip() for c in _env("ADMIN_ROLE_CODES", "").split(",") if c.strip()}
        code_rol = str(data.get("codeRol") or "").strip()

        # Permite forzar rol de admin del portal desde la UI (sin depender del rol del microservicio)
        profile, _ = PortalUserProfile.objects.get_or_create(user=user)

        if profile.force_staff:
            user.is_staff = True
            user.is_superuser = True
        elif (username in admin_users) or (code_rol and code_rol in admin_role_codes):
            user.is_staff = True
            user.is_superuser = True
        else:
            user.is_staff = False
            user.is_superuser = False

        user.save()

        if request is not None:
            request.session["ms_user"] = data.get("user") or username
            request.session["ms_userName"] = data.get("userName") or username
            request.session["ms_role"] = data.get("nameRol") or ""
            request.session["ms_role_code"] = data.get("codeRol") or ""
            request.session["ms_resultMessage"] = data.get("resultMessage") or ""
            request.session["ms_token"] = data.get("token") or ""

        return user

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None
