from django.conf import settings
from django.db import models


class PortalUserProfile(models.Model):
    """Preferencias de acceso del portal por usuario.

    NOTA:
    - El login real se hace contra el microservicio.
    - Este perfil controla el *rol del portal* (admin/no admin) y permite
      bloquear usuarios aunque el microservicio los valide.
    """

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="portal_profile")
    force_staff = models.BooleanField(default=False, help_text="Si está activo, este usuario verá el menú de Administración y podrá gestionar usuarios.")
    notes = models.CharField(max_length=255, blank=True, default="")

    class Meta:
        verbose_name = "Portal user profile"
        verbose_name_plural = "Portal user profiles"

    def __str__(self) -> str:  # pragma: no cover
        return f"PortalUserProfile({self.user.username})"
