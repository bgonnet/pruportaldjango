from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_http_methods

from accounts.models import PortalUserProfile
from .user_forms import PortalUserForm, SetPasswordForm


def staff_required(view_func):
    return login_required(user_passes_test(lambda u: u.is_staff)(view_func))


@staff_required
def user_list(request):
    users = User.objects.all().order_by("username")

    entries = []
    for u in users:
        profile, _ = PortalUserProfile.objects.get_or_create(user=u)
        entries.append({"user": u, "profile": profile})

    return render(
        request,
        "users/user_list.html",
        {
            "page_title": "Usuarios",
            "entries": entries,
        },
    )


@staff_required
@require_http_methods(["GET", "POST"])
def user_create(request):
    form = PortalUserForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        messages.success(request, f"Usuario '{user.username}' creado.")
        return redirect(reverse("user_list"))
    return render(request, "users/user_form.html", {"page_title": "Nuevo usuario", "form": form, "is_new": True})


@staff_required
@require_http_methods(["GET", "POST"])
def user_edit(request, pk: int):
    user = get_object_or_404(User, pk=pk)
    form = PortalUserForm(request.POST or None, instance=user)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        messages.success(request, f"Usuario '{user.username}' actualizado.")
        return redirect(reverse("user_list"))
    return render(request, "users/user_form.html", {"page_title": f"Editar usuario: {user.username}", "form": form, "is_new": False, "obj": user})


@staff_required
@require_http_methods(["POST"])
def user_toggle_active(request, pk: int):
    user = get_object_or_404(User, pk=pk)

    # Evitar que un admin se bloquee a si mismo accidentalmente
    if user.id == request.user.id:
        messages.error(request, "No puedes desactivar tu propio usuario.")
        return redirect(reverse("user_list"))

    user.is_active = not user.is_active
    user.save(update_fields=["is_active"])
    messages.success(request, f"Usuario '{user.username}' ahora está {'ACTIVO' if user.is_active else 'INACTIVO' }.")
    return redirect(reverse("user_list"))


@staff_required
@require_http_methods(["GET", "POST"])
def user_set_password(request, pk: int):
    user = get_object_or_404(User, pk=pk)
    form = SetPasswordForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user.set_password(form.cleaned_data["password1"])
        user.save(update_fields=["password"])
        messages.success(request, f"Contraseña actualizada para '{user.username}'.")
        return redirect(reverse("user_list"))
    return render(request, "users/user_password.html", {"page_title": f"Cambiar contraseña: {user.username}", "form": form, "obj": user})
