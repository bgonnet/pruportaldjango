from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="BIRecord",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("referencia", models.CharField(db_index=True, max_length=64)),
                ("estado", models.CharField(db_index=True, max_length=20)),
                ("categoria", models.CharField(db_index=True, default="General", max_length=30)),
                ("fecha", models.DateField(db_index=True)),
                ("valor", models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
        ),
    ]
