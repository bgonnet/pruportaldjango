import datetime
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum
from django.shortcuts import render
from .models import BIRecord

@login_required
def consulta_bi(request):
    referencia = (request.GET.get("referencia") or "").strip()
    estado = (request.GET.get("estado") or "").strip()
    fecha_desde = (request.GET.get("fecha_desde") or "").strip()
    fecha_hasta = (request.GET.get("fecha_hasta") or "").strip()

    qs = BIRecord.objects.all().order_by("-fecha")[:2000]

    if referencia:
        qs = qs.filter(referencia__icontains=referencia)
    if estado:
        qs = qs.filter(estado__iexact=estado)

    def parse_date(s):
        try:
            return datetime.date.fromisoformat(s)
        except Exception:
            return None

    d1 = parse_date(fecha_desde)
    d2 = parse_date(fecha_hasta)
    if d1:
        qs = qs.filter(fecha__gte=d1)
    if d2:
        qs = qs.filter(fecha__lte=d2)

    return render(request, "bi/consulta_bi.html", {
        "page_title": "Consulta BI",
        "referencia": referencia,
        "estado": estado,
        "fecha_desde": fecha_desde,
        "fecha_hasta": fecha_hasta,
        "rows": list(qs),
    })

@login_required
def indicadores_bi(request):
    total = BIRecord.objects.count()
    by_estado = list(BIRecord.objects.values("estado").annotate(c=Count("id")).order_by("estado"))
    by_categoria = list(BIRecord.objects.values("categoria").annotate(c=Count("id")).order_by("categoria"))

    today = datetime.date.today()
    dfrom = today - datetime.timedelta(days=13)
    series = list(
        BIRecord.objects.filter(fecha__gte=dfrom, fecha__lte=today)
        .values("fecha")
        .annotate(v=Sum("valor"), c=Count("id"))
        .order_by("fecha")
    )

    return render(request, "bi/indicadores_bi.html", {
        "page_title": "Indicadores BI",
        "has_data": total > 0,
        "by_estado": by_estado,
        "by_categoria": by_categoria,
        "series": [{"fecha": s["fecha"].isoformat(), "valor": float(s["v"] or 0), "count": s["c"]} for s in series],
        "total": total,
    })
