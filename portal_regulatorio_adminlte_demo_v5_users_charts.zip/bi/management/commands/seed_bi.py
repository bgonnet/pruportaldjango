import random
import datetime
from django.core.management.base import BaseCommand
from bi.models import BIRecord

class Command(BaseCommand):
    help = "Genera data demo para BIRecord"

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Borra datos existentes")
        parser.add_argument("--n", type=int, default=150, help="Cantidad de registros a crear")

    def handle(self, *args, **options):
        if options["reset"]:
            BIRecord.objects.all().delete()
            self.stdout.write(self.style.WARNING("BIRecord borrado."))

        n = options["n"]
        estados = ["OK", "PENDIENTE", "ERROR"]
        categorias = ["Revenue", "Fraude", "Soporte", "General"]

        today = datetime.date.today()
        for _ in range(n):
            fecha = today - datetime.timedelta(days=random.randint(0, 40))
            BIRecord.objects.create(
                referencia=f"REF-{random.randint(100000,999999)}",
                estado=random.choice(estados),
                categoria=random.choice(categorias),
                fecha=fecha,
                valor=round(random.uniform(1, 5000), 2),
            )
        self.stdout.write(self.style.SUCCESS(f"Creado {n} registros BIRecord."))
