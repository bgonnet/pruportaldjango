# Portal Regulatorio - Demo AdminLTE (Django + Postgres + Login por Microservicio)

Este ZIP es un **demo funcional** para construir portales rápidamente con **Django + AdminLTE v3**:
- Login estilo AdminLTE para el portal
- Login del **/admin/** también autenticando contra el microservicio
- Sidebar con menú tipo AdminLTE (incluye 2 vistas demo y placeholders)
- Persistencia en **PostgreSQL** usando `DATABASE_URL`
- Gestión de usuarios/roles en Django Admin (según reglas de `ADMIN_USERS` / `ADMIN_ROLE_CODES`)

## 1) Requisitos
- Python 3.11+ (recomendado)
- PostgreSQL corriendo localmente
- (Opcional) `virtualenv` o `venv`

## 2) Instalación (Windows PowerShell)
```powershell
cd portal_regulatorio_adminlte_demo
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt

copy .env.example .env
# Edita .env con tus valores reales (NO subas credenciales a Git)
```

## 3) Migraciones y ejecución
```powershell
python manage.py migrate
python manage.py runserver
```

- Portal: http://127.0.0.1:8000/
- Login: http://127.0.0.1:8000/accounts/login/
- Admin: http://127.0.0.1:8000/admin/

## 4) Login por microservicio
El backend de autenticación llama a:
`MS_LOGIN_URL` con payload `{ user, password, ip }` y headers configurables en `.env`.

**Importante**
- `MS_AUTH_BASIC` se carga desde `.env`. No está hardcodeado.
- En `ADMIN_USERS` y/o `ADMIN_ROLE_CODES` defines quién entra al Django Admin (`is_staff` / `is_superuser`).

## 5) Agregar menús y vistas rápido
- Menú: `portal/menu.py`
- Vistas demo: `portal/views.py`
- Templates: `templates/portal/*.html`

Para agregar una opción:
1) Crea view en `portal/views.py`
2) Agrega ruta en `config/urls.py`
3) Agrega item en `portal/menu.py`

## Referencias
- AdminLTE v3 docs: https://adminlte.io/docs/3.2/
- CDNJS AdminLTE: https://cdnjs.com/libraries/admin-lte
