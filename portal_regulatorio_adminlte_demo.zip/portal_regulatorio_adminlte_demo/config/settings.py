from pathlib import Path
import os
from dotenv import load_dotenv
import dj_database_url

BASE_DIR = Path(__file__).resolve().parent.parent

load_dotenv(BASE_DIR / ".env")

SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")
DEBUG = os.getenv("DEBUG", "0") == "1"

ALLOWED_HOSTS = [h.strip() for h in os.getenv("ALLOWED_HOSTS", "127.0.0.1,localhost").split(",") if h.strip()]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    # local apps
    "accounts",
    "portal",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "portal.context_processors.menu",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

DATABASES = {
    "default": dj_database_url.config(
        default=os.getenv("DATABASE_URL", f"postgres://postgres:postgres@localhost:5432/portal_regulatorio"),
        conn_max_age=600,
    )
}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "es-ec"
TIME_ZONE = "America/Guayaquil"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGIN_URL = "/accounts/login/"
LOGIN_REDIRECT_URL = "/"
LOGOUT_REDIRECT_URL = "/accounts/login/"

AUTHENTICATION_BACKENDS = [
    "accounts.backends.MicroserviceBackend",
    "django.contrib.auth.backends.ModelBackend",  # optional fallback for local superusers if you enable them
]

# ============
# Microservice config
# ============
MS_LOGIN_URL = os.getenv("MS_LOGIN_URL", "")
MS_AUTH_BASIC = os.getenv("MS_AUTH_BASIC", "")
MS_VERIFY_SSL = os.getenv("MS_VERIFY_SSL", "1") == "1"

MS_STATIC_HEADERS = {
    "country": os.getenv("MS_COUNTRY", "EC"),
    "lang": os.getenv("MS_LANG", "es"),
    "entity": os.getenv("MS_ENTITY", "OTECEL"),
    "system": os.getenv("MS_SYSTEM", "RPA"),
    "subsystem": os.getenv("MS_SUBSYSTEM", "EPCXXX"),
    "originator": os.getenv("MS_ORIGINATOR", "ms-gateway-generic-portal-huawei"),
    "userId": os.getenv("MS_USERID", "gateway"),
    "destination": os.getenv("MS_DESTINATION", "environment-ms"),
    "operation": "login",
    "msgType": "REQUEST",
    "Content-Type": "application/json",
}

ADMIN_USERS = {u.strip() for u in os.getenv("ADMIN_USERS", "").split(",") if u.strip()}
ADMIN_ROLE_CODES = {c.strip() for c in os.getenv("ADMIN_ROLE_CODES", "").split(",") if c.strip()}
