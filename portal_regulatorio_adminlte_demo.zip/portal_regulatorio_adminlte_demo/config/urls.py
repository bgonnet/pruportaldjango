from django.contrib import admin
from django.urls import path, include
from accounts.views import AdminLoginView

urlpatterns = [
    # Override admin login to use our AdminLTE login (still authenticates to microservice)
    path("admin/login/", AdminLoginView.as_view(), name="admin_login"),
    path("admin/", admin.site.urls),

    path("accounts/", include("accounts.urls")),
    path("", include("portal.urls")),
]
