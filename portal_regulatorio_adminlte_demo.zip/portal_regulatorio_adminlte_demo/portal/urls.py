from django.urls import path
from . import views

app_name = "portal"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("demo/uno/", views.demo_uno, name="demo_uno"),
    path("demo/dos/", views.demo_dos, name="demo_dos"),
    path("ui/<slug:page>/", views.ui_placeholder, name="ui_placeholder"),
]
