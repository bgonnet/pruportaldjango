from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def dashboard(request):
    return render(request, "portal/dashboard.html")

@login_required
def demo_uno(request):
    return render(request, "portal/demo_uno.html")

@login_required
def demo_dos(request):
    return render(request, "portal/demo_dos.html")

@login_required
def ui_placeholder(request, page):
    # Placeholder pages for showing menu options quickly
    return render(request, "portal/placeholder.html", {"page": page})
