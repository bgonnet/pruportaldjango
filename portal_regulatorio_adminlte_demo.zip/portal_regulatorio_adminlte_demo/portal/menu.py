from dataclasses import dataclass
from typing import List, Optional

@dataclass
class MenuItem:
    label: str
    icon: str = "far fa-circle"
    url: str = "#"
    children: Optional[List["MenuItem"]] = None
    badge: str = ""

def build_menu():
    return [
        MenuItem(label="Dashboard", icon="fas fa-tachometer-alt", url="/"),
        MenuItem(
            label="Demos",
            icon="fas fa-flask",
            children=[
                MenuItem(label="Demo vista 1", icon="far fa-circle", url="/demo/uno/"),
                MenuItem(label="Demo vista 2", icon="far fa-circle", url="/demo/dos/"),
            ],
        ),
        MenuItem(
            label="AdminLTE (placeholders)",
            icon="fas fa-th",
            children=[
                MenuItem(label="Widgets", url="/ui/widgets/"),
                MenuItem(label="Charts", url="/ui/charts/"),
                MenuItem(label="Forms", url="/ui/forms/"),
                MenuItem(label="Tables", url="/ui/tables/"),
                MenuItem(label="Calendar", url="/ui/calendar/"),
            ],
        ),
        MenuItem(label="Administración de Usuarios", icon="fas fa-users-cog", url="/admin/"),
    ]
