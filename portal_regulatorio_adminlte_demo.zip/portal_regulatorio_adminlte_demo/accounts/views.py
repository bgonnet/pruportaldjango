from django.contrib import messages
from django.contrib.auth import login, logout
from django.shortcuts import redirect
from django.urls import reverse
from django.views.generic import FormView
from django.conf import settings

from .forms import MicroserviceAuthenticationForm

class LoginView(FormView):
    template_name = "accounts/login.html"
    form_class = MicroserviceAuthenticationForm

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs

    def form_valid(self, form):
        user = form.get_user()
        login(self.request, user)

        # Copiar token/rol a session si el backend lo adjuntó al user
        ms_data = getattr(user, "_ms_data", {}) or {}
        token = ms_data.get("token") or ""
        self.request.session["ms_token"] = token
        self.request.session["ms_role"] = ms_data.get("nameRol") or ms_data.get("codeRol") or ""
        self.request.session["ms_resultMessage"] = ms_data.get("resultMessage") or ""

        next_url = self.request.GET.get("next") or settings.LOGIN_REDIRECT_URL
        return redirect(next_url)

class AdminLoginView(LoginView):
    """Login AdminLTE pero para /admin/login/ (redirige por defecto al admin)."""
    def form_valid(self, form):
        resp = super().form_valid(form)
        # Si viene sin next, al admin
        if not self.request.GET.get("next"):
            return redirect("/admin/")
        return resp

def logout_view(request):
    logout(request)
    messages.info(request, "Sesión cerrada.")
    return redirect(reverse("accounts:login"))
