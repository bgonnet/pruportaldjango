
import os, uuid, datetime, logging, requests
from django.contrib.auth.backends import BaseBackend
from django.contrib.auth.models import User, Group

log = logging.getLogger(__name__)

def _ms_headers():
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    return {
        "country":      os.getenv("MSAUTH_COUNTRY", "EC"),
        "lang":         os.getenv("MSAUTH_LANG", "es"),
        "entity":       os.getenv("MSAUTH_ENTITY", "OTECEL"),
        "system":       os.getenv("MSAUTH_SYSTEM", "RPA"),
        "subsystem":    os.getenv("MSAUTH_SUBSYSTEM", "EPCXXX"),
        "originator":   os.getenv("MSAUTH_ORIGINATOR", "portal"),
        "userId":       os.getenv("MSAUTH_USERID", "gateway"),
        "operation":    os.getenv("MSAUTH_OPERATION", "login"),
        "destination":  os.getenv("MSAUTH_DESTINATION", "environment-ms"),
        "execId":       str(uuid.uuid4()),
        "msgId":        str(uuid.uuid4()),
        "timestamp":    ts,
        "msgType":      os.getenv("MSAUTH_MSGTYPE", "REQUEST"),
        "Authorization":"Basic " + os.getenv("MSAUTH_AUTH_BASIC", ""),
        "Content-Type": "application/json",
        "pid":          os.getenv("MSAUTH_PID", ""),
    }

class MicroserviceBackend(BaseBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        url      = os.getenv("MSAUTH_LOGIN_URL")
        timeout  = float(os.getenv("MSAUTH_TIMEOUT", "5"))
        verify   = os.getenv("MSAUTH_VERIFY", "true").lower() == "true"
        if not url or not username or not password:
            return None
        payload = {"user": username, "password": password, "ip": request.META.get("REMOTE_ADDR", "")}
        headers = _ms_headers()
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=timeout, verify=verify)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            log.error(f"[MS-AUTH] error: {e}")
            return None
        if data.get("status") != "A" or not data.get("token"):
            log.warning(f"[MS-AUTH] login rechazado: {data}")
            return None
        uname = (data.get("userName") or data.get("user") or username).strip()
        role  = (data.get("nameRol") or data.get("codeRol") or "RolDesconocido").strip()
        user, created = User.objects.get_or_create(username=uname)
        if created:
            user.email = ""
        user.is_active = True
        user.save()
        grp, _ = Group.objects.get_or_create(name=role)
        user.groups.set([grp])
        user.save()
        if request:
            request.session["MS_TOKEN"]     = data.get("token")
            request.session["MS_AUTH_DATA"] = {
                "user": data.get("user"),
                "status": data.get("status"),
                "codeRol": data.get("codeRol"),
                "nameRol": data.get("nameRol"),
                "resultMessage": data.get("resultMessage"),
            }
        return user

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None
