
# Django AdminLTE (AppSeed) — Starter v3 con login MS + PostgreSQL + Vista ECU911

- Librería **`django-admin-adminlte`** + **URLs** (`admin_adminlte.urls`) para ver **todas las páginas demo** (Dashboard, Widgets, Forms, Calendar, etc.).
- **Login del admin** contra el **microservicio** (JWT en sesión; rol → Group).
- **PostgreSQL** por `DATABASE_URL`.
- **Vista admin**: `/admin/ecu911/consulta/` (Formulario + llamada SOAP) con **acceso rápido** en `admin/index` y **link en sidebar**.
- **Branding**: *Portal Regulatorio* en admin y overrides para demo AdminLTE.

## Run
```powershell
./scripts/setup.ps1
python project/manage.py createsuperuser
./scripts/run.ps1
```

## PostgreSQL
```sql
CREATE USER portal_user WITH PASSWORD 'TuPasswordFuerte123!';
CREATE DATABASE portal_regulatorio OWNER portal_user;
GRANT ALL PRIVILEGES ON DATABASE portal_regulatorio TO portal_user;
```
`.env`:
```
DATABASE_URL=postgres://portal_user:TuPasswordFuerte123!@localhost:5432/portal_regulatorio
```

## Cambiar brand "AdminLTE 3"
- Admin: `project/templates/admin/base_site.html`
- Páginas AdminLTE: overrides en `project/templates/admin_adminlte/` (p.e. `includes/navbar.html`).
