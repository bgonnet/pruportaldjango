
$activate = ".\.venv\Scripts\Activate.ps1"
& $activate
$env:DJANGO_SETTINGS_MODULE="project.settings"
python project/manage.py runserver 0.0.0.0:8000
