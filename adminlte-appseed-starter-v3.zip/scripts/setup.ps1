
Param([string]$PythonExe = "python")
Write-Host "[setup] Creando venv e instalando dependencias..." -ForegroundColor Cyan
$envPath = ".\.venv"
if (!(Test-Path $envPath)) { & $PythonExe -m venv $envPath }
$activate = ".\.venv\Scripts\Activate.ps1"
& $activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { Write-Error "[setup] pip install falló."; exit $LASTEXITCODE }
Write-Host "[setup] Migrando base de datos..." -ForegroundColor Cyan
python project/manage.py migrate
if ($LASTEXITCODE -ne 0) { Write-Error "[setup] migrate falló."; exit $LASTEXITCODE }
Write-Host "[setup] OK. Crea tu superusuario si lo necesitas." -ForegroundColor Yellow
