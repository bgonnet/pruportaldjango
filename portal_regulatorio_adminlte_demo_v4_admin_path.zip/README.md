# Portal Regulatorio - Demo AdminLTE v3 + Django (v4)

## Lo que pediste: que el portal se vea desde /admin/
- **Portal AdminLTE (UI completa):** http://127.0.0.1:8000/admin/
- **Django Admin real (usuarios, modelos):** http://127.0.0.1:8000/djadmin/

> Esto evita el problema típico de “pantalla en blanco” en /admin/ cuando se intenta mezclar AdminLTE con el admin nativo.

## Setup
```bash
python -m venv .venv
# Windows: .\.venv\Scripts\activate
pip install -r requirements.txt
# Copia .env.example a .env y ajusta MS_AUTH_BASIC + DATABASE_URL
python manage.py migrate
python manage.py seed_bi --reset --n 150
python manage.py runserver
```

## Login
- Ir a: http://127.0.0.1:8000/admin/login/
- Autentica contra MS_LOGIN_URL (Movistar PRE)

## ECU911
- Requiere conectividad a la IP 10.112.162.28 (intranet).
