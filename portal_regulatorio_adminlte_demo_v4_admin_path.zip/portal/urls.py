from django.urls import path
from accounts.views import login_view, logout_view
from . import views
from bi import views as bi_views
from ecu911 import views as ecu_views

urlpatterns = [
    path("login/", login_view, name="portal_login"),
    path("logout/", logout_view, name="portal_logout"),

    path("", views.dashboard, name="dashboard"),
    path("bi/consulta/", bi_views.consulta_bi, name="consulta_bi"),
    path("bi/indicadores/", bi_views.indicadores_bi, name="indicadores_bi"),
    path("ecu911/consulta/", ecu_views.consulta_ecu911, name="consulta_ecu911"),
]
