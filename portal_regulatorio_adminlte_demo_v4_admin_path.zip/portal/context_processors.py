from .menu import get_menu

def sidebar_menu(request):
    return {"SIDEBAR_MENU": get_menu()}
