def get_menu():
    return [
        {"type": "header", "label": "NAVEGACIÓN"},
        {"type": "item", "label": "Dashboard", "icon": "fas fa-tachometer-alt", "url": "/admin/"},
        {"type": "header", "label": "BI / Servicios"},
        {"type": "item", "label": "Consulta BI", "icon": "fas fa-search", "url": "/admin/bi/consulta/"},
        {"type": "item", "label": "Consulta Ecu 911", "icon": "fas fa-phone", "url": "/admin/ecu911/consulta/"},
        {"type": "item", "label": "Indicadores BI", "icon": "fas fa-chart-line", "url": "/admin/bi/indicadores/"},
        {"type": "header", "label": "ADMINISTRACIÓN"},
        {"type": "item", "label": "Usuarios (Django Admin)", "icon": "fas fa-users-cog", "url": "/djadmin/auth/user/"},
        {"type": "item", "label": "Cerrar sesión", "icon": "fas fa-sign-out-alt", "url": "/admin/logout/"},
    ]
