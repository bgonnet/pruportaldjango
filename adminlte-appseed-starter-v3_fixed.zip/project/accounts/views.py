
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse

@login_required
def auth_status(request):
    return JsonResponse({
        "is_authenticated": request.user.is_authenticated,
        "user": request.user.username,
        "has_token": bool(request.session.get("MS_TOKEN")),
        "auth_data": request.session.get("MS_AUTH_DATA"),
    })
