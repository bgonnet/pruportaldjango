
from django.contrib import admin
from django.urls import path, include
from portal.views_admin import ecu911_consulta_admin

urlpatterns = [
    path('', include('admin_adminlte.urls')),
    path('admin/', admin.site.urls),
    path('admin/ecu911/consulta/', ecu911_consulta_admin, name='ecu911_consulta_admin'),
    path('accounts/', include('accounts.urls')),
]
