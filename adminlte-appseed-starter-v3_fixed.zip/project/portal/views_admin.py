
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import requests

@staff_member_required
@csrf_exempt
def ecu911_consulta_admin(request):
    result_xml = None
    error = None
    numero = ""
    if request.method == "POST":
        numero = (request.POST.get("numero") or "").strip()
        # NOTE: Use single quotes (or triple quotes) so the XML double-quotes
        # inside attributes don't break Python syntax.
        envelope = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" '
            'xmlns:tem="http://tempuri.org/">'
            '<soapenv:Header/>'
            '<soapenv:Body>'
            '<tem:ConsultaLocalizacion>'
            f'<tem:Numero>{numero}</tem:Numero>'
            '<tem:Institucion>Prueba</tem:Institucion>'
            '<tem:Usuario>9915e0d72085</tem:Usuario>'
            '<tem:Fecha></tem:Fecha>'
            '<tem:Motivo>Motivo</tem:Motivo>'
            '<tem:Descripcion>Descripcion</tem:Descripcion>'
            '</tem:ConsultaLocalizacion>'
            '</soapenv:Body>'
            '</soapenv:Envelope>'
        )
        try:
            resp = requests.post(
                "http://10.112.162.28:32100/Otecel.WebServices.ECU911V2/Rastreo.asmx",
                data=envelope.encode("utf-8"),
                headers={
                    "Content-Type": "text/xml",
                    "SOAPAction": "http://tempuri.org/ConsultaLocalizacion",
                },
                timeout=15,
            )
            resp.raise_for_status()
            result_xml = resp.text
        except Exception as e:
            error = str(e)

    return render(request, "admin/ecu911_consulta.html", {
        "numero": numero,
        "result_xml": result_xml,
        "error": error,
    })
