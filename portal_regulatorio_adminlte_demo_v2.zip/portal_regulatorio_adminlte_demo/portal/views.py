from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone

import requests
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.views.decorators.http import require_http_methods


@login_required
def dashboard(request):
    return render(request, "portal/dashboard.html")


@login_required
def demo_uno(request):
    return render(request, "portal/demo_uno.html")


@login_required
def demo_dos(request):
    return render(request, "portal/demo_dos.html")


@login_required
def ui_placeholder(request, page):
    # Placeholder pages for showing menu options quickly
    return render(request, "portal/placeholder.html", {"page": page})


@login_required
@require_http_methods(["GET"])
def consulta_bi(request):
    """
    Vista demo para búsquedas (inputs) + resultados en DataTables.
    Por ahora usa data mock; luego puedes reemplazar por una consulta real a Postgres.
    """
    q_id = (request.GET.get("id") or "").strip()
    q_estado = (request.GET.get("estado") or "").strip()
    q_fecha = (request.GET.get("fecha") or "").strip()

    rows = [
        {"id": 1001, "estado": "OK", "fecha": "2025-12-10", "descripcion": "Registro demo 1"},
        {"id": 1002, "estado": "PENDIENTE", "fecha": "2025-12-11", "descripcion": "Registro demo 2"},
        {"id": 1003, "estado": "ERROR", "fecha": "2025-12-12", "descripcion": "Registro demo 3"},
    ]

    # Filtro simple (demo)
    def match(r):
        if q_id and str(r["id"]) != q_id:
            return False
        if q_estado and q_estado.lower() not in r["estado"].lower():
            return False
        if q_fecha and q_fecha != r["fecha"]:
            return False
        return True

    filtered = [r for r in rows if match(r)]

    return render(
        request,
        "portal/consulta_bi.html",
        {
            "q_id": q_id,
            "q_estado": q_estado,
            "q_fecha": q_fecha,
            "rows": filtered,
        },
    )


def _soap_envelope(numero: str, institucion: str, usuario: str, fecha: str, motivo: str, descripcion: str) -> str:
    # SOAP 1.1 envelope (text/xml + SOAPAction)
    return f"""<?xml version="1.0" encoding="utf-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
  <soapenv:Header/>
  <soapenv:Body>
    <tem:ConsultaLocalizacion>
      <tem:Numero>{numero}</tem:Numero>
      <tem:Institucion>{institucion}</tem:Institucion>
      <tem:Usuario>{usuario}</tem:Usuario>
      <tem:Fecha>{fecha}</tem:Fecha>
      <tem:Motivo>{motivo}</tem:Motivo>
      <tem:Descripcion>{descripcion}</tem:Descripcion>
    </tem:ConsultaLocalizacion>
  </soapenv:Body>
</soapenv:Envelope>"""


@login_required
@require_http_methods(["GET", "POST"])
def consulta_ecu911(request):
    """
    Vista demo que consume el servicio SOAP de ECU-911 para ConsultaLocalizacion.
    Si el endpoint no es accesible desde tu PC/red, mostrará un error con el detalle.
    """
    numero = ""
    raw_response = ""
    http_status = None
    error = ""

    # Config por .env
    ecu911_url = os.getenv("ECU911_URL", "http://10.112.162.28:32100/Otecel.WebServices.ECU911V2/Rastreo.asmx")
    soap_action = os.getenv("ECU911_SOAP_ACTION", "http://tempuri.org/ConsultaLocalizacion")
    institucion = os.getenv("ECU911_INSTITUCION", "Prueba")
    usuario = os.getenv("ECU911_USUARIO", "9915e0d72085")
    motivo = os.getenv("ECU911_MOTIVO", "Motivo")
    descripcion = os.getenv("ECU911_DESCRIPCION", "Descripcion")
    timeout_sec = int(os.getenv("ECU911_TIMEOUT", "15"))

    if request.method == "POST":
        numero = (request.POST.get("numero") or "").strip()
        if not numero:
            messages.error(request, "Ingresa un número de teléfono.")
        else:
            # Fecha opcional (ISO); si lo dejas vacío, el servicio decidirá qué hacer
            fecha = (request.POST.get("fecha") or "").strip()
            envelope = _soap_envelope(numero, institucion, usuario, fecha, motivo, descripcion)

            headers = {
                "Content-Type": "text/xml; charset=utf-8",
                "SOAPAction": soap_action,
                # Trazabilidad útil
                "execId": str(uuid.uuid4()),
                "msgId": str(uuid.uuid4()),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            try:
                resp = requests.post(ecu911_url, data=envelope.encode("utf-8"), headers=headers, timeout=timeout_sec)
                http_status = resp.status_code
                raw_response = resp.text
                if resp.ok:
                    messages.success(request, f"Consulta realizada. HTTP {resp.status_code}.")
                else:
                    messages.error(request, f"El servicio respondió con error HTTP {resp.status_code}.")
            except requests.RequestException as ex:
                error = str(ex)
                messages.error(request, "No se pudo conectar al servicio ECU-911 (ver detalle abajo).")

    return render(
        request,
        "portal/consulta_ecu911.html",
        {
            "numero": numero,
            "ecu911_url": ecu911_url,
            "http_status": http_status,
            "raw_response": raw_response,
            "error": error,
        },
    )


@login_required
@require_http_methods(["GET"])
def indicadores_bi(request):
    """
    Vista demo de gráficos con Chart.js (similar al stack usado por AdminLTE 3).
    Luego puedes reemplazar 'labels' y 'data' con datos reales desde Postgres.
    """
    # Datos mock
    labels = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
    serie1 = [12, 19, 3, 5, 2, 3, 9]
    serie2 = [8, 11, 7, 6, 4, 5, 10]

    return render(
        request,
        "portal/indicadores_bi.html",
        {
            "labels": labels,
            "serie1": serie1,
            "serie2": serie2,
        },
    )
