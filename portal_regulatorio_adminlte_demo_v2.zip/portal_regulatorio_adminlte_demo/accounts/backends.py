import uuid
from datetime import datetime, timezone
import requests
from django.conf import settings
from django.contrib.auth import get_user_model

User = get_user_model()

def _iso_now():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="milliseconds")

def call_login_service(username: str, password: str, ip: str | None = "") -> dict:
    if not settings.MS_LOGIN_URL:
        raise RuntimeError("MS_LOGIN_URL no está configurada")

    headers = dict(settings.MS_STATIC_HEADERS)
    # dynamic headers
    headers.update({
        "execId": str(uuid.uuid4()),
        "msgId": str(uuid.uuid4()),
        "timestamp": _iso_now(),
        "pid": str(uuid.uuid4()),
    })
    if settings.MS_AUTH_BASIC:
        headers["Authorization"] = settings.MS_AUTH_BASIC

    payload = {"user": username, "password": password, "ip": ip or ""}

    resp = requests.post(
        settings.MS_LOGIN_URL,
        headers=headers,
        json=payload,
        timeout=15,
        verify=settings.MS_VERIFY_SSL,
    )
    # Some gateways may return 200 with error info; keep json either way
    try:
        data = resp.json()
    except Exception:
        data = {"_raw": resp.text}

    if resp.status_code != 200:
        data["_http_status"] = resp.status_code
        raise ValueError(f"Login service HTTP {resp.status_code}")

    return data

class MicroserviceBackend:
    """Autenticación contra microservicio y creación/actualización del usuario en Django."""

    def authenticate(self, request, username=None, password=None, **kwargs):
        if not username or not password:
            return None

        ip = ""
        if request is not None:
            ip = request.META.get("REMOTE_ADDR", "") or ""

        try:
            data = call_login_service(username=username, password=password, ip=ip)
        except Exception:
            return None

        # Criterio simple: status == 'A' => activo
        if data.get("status") not in (None, "", "A"):
            return None

        user, _ = User.objects.get_or_create(username=username)
        user.is_active = True

        # Permisos para entrar a /admin/
        role_code = str(data.get("codeRol") or "").strip()
        if username in settings.ADMIN_USERS or (role_code and role_code in settings.ADMIN_ROLE_CODES):
            user.is_staff = True
            user.is_superuser = True
        else:
            # Para portal, basta con estar autenticado
            user.is_staff = False
            user.is_superuser = False

        user.save()

        # Guardamos payload temporal en el request para que la vista lo copie a session
        user._ms_data = data  # type: ignore[attr-defined]
        return user

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None
