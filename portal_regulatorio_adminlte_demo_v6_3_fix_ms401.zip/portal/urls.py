from django.urls import path
from accounts.views import login_view, logout_view
from . import views
from . import user_views
from bi import views as bi_views
from ecu911 import views as ecu_views

urlpatterns = [
    path("login/", login_view, name="portal_login"),
    path("logout/", logout_view, name="portal_logout"),

    path("", views.dashboard, name="dashboard"),
    path("bi/consulta/", bi_views.consulta_bi, name="consulta_bi"),
    path("bi/indicadores/", bi_views.indicadores_bi, name="indicadores_bi"),
    path("ecu911/consulta/", ecu_views.consulta_ecu911, name="consulta_ecu911"),

    # Administración de usuarios (look AdminLTE)
    path("usuarios/", user_views.user_list, name="user_list"),
    path("usuarios/nuevo/", user_views.user_create, name="user_create"),
    path("usuarios/<int:pk>/editar/", user_views.user_edit, name="user_edit"),
    path("usuarios/<int:pk>/toggle/", user_views.user_toggle_active, name="user_toggle"),
    path("usuarios/<int:pk>/password/", user_views.user_set_password, name="user_set_password"),
]
