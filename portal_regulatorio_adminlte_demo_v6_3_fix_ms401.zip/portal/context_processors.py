from .menu import get_menu
from accounts.models import PortalUserProfile


def sidebar_menu(request):
    return {"SIDEBAR_MENU": get_menu(request)}


def ms_context(request):
    """Expose datos del microservicio de forma segura para templates.

    Evita accesos directos a request.session.<key> que pueden lanzar
    VariableDoesNotExist si el key no existe.
    """
    if not getattr(request, "user", None) or not request.user.is_authenticated:
        return {
            "ms_userName": "",
            "ms_status": "",
            "ms_role_code": "",
            "ms_role": "",
            "ms_resultMessage": "",
        }

    # Preferir sesión (rápido); fallback a perfil (persistido)
    s = getattr(request, "session", {})
    ms_role = ""
    ms_role_code = ""
    ms_status = ""
    ms_result = ""
    ms_user_name = ""

    try:
        ms_role = s.get("ms_role", "")
        ms_role_code = s.get("ms_role_code", "")
        ms_status = s.get("ms_status", "")
        ms_result = s.get("ms_resultMessage", "")
        ms_user_name = s.get("ms_userName", "")
    except Exception:
        # si session no está lista por alguna razón
        pass

    if not (ms_role or ms_role_code or ms_status or ms_result or ms_user_name):
        try:
            profile, _ = PortalUserProfile.objects.get_or_create(user=request.user)
            ms_role = profile.ms_name_rol or ""
            ms_role_code = profile.ms_code_rol or ""
            ms_status = profile.ms_status or ""
            ms_result = profile.ms_result_message or ""
            ms_user_name = profile.ms_user_name or request.user.username
        except Exception:
            ms_user_name = request.user.username

    return {
        "ms_userName": ms_user_name,
        "ms_status": ms_status,
        "ms_role_code": ms_role_code,
        "ms_role": ms_role,
        "ms_resultMessage": ms_result,
    }
