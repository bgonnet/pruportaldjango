import os
import uuid
import datetime
import requests

from django.contrib.auth.backends import ModelBackend
from django.contrib.auth.models import User
from django.utils import timezone

from .models import PortalUserProfile


def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def _normalize_basic(value: str) -> str:
    """Normaliza MS_AUTH_BASIC.

    Acepta:
      - 'Basic <base64>'
      - '<base64>'
      - valores con comillas
    """
    v = (value or "").strip()
    if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
        v = v[1:-1].strip()
    if not v:
        return ""
    if v.lower().startswith("basic "):
        return "Basic " + v[6:].strip()
    # Si parece ser solo el base64 (sin espacios), prefijar Basic
    if " " not in v:
        return "Basic " + v
    return v


def _timestamp_value() -> str:
    """Genera timestamp para header.

    - Si MS_TIMESTAMP_FIXED está configurado, lo usa tal cual.
    - Si MS_TIMESTAMP_OFFSET está configurado (ej: +05:00), lo formatea con milisegundos y ese offset.
    - Caso contrario, ISO UTC.
    """
    fixed = _env("MS_TIMESTAMP_FIXED", "").strip()
    if fixed:
        return fixed

    offset = _env("MS_TIMESTAMP_OFFSET", "").strip()
    if offset:
        try:
            sign = 1 if offset[0] == "+" else -1
            hh = int(offset[1:3])
            mm = int(offset[4:6])
            tz = datetime.timezone(sign * datetime.timedelta(hours=hh, minutes=mm))
            dt = datetime.datetime.now(tz)
            # '%f' = microsegundos; cortamos a milisegundos para parecerse al ejemplo
            base = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
            return f"{base}{offset}"
        except Exception:
            # fallback
            return datetime.datetime.now(datetime.timezone.utc).isoformat()

    # Por defecto: usar timezone local del sistema y formatear como YYYY-MM-DDTHH:MM:SS.mmm±HH:MM
    dt = datetime.datetime.now().astimezone()
    off = dt.strftime('%z')  # e.g. -0500
    off = off[:3] + ':' + off[3:] if off else '+00:00'
    base = dt.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
    return f"{base}{off}"


class LocalAdminBackend(ModelBackend):
    """Autenticación local SOLO para el usuario admin del portal (por seguridad)."""

    def authenticate(self, request, username=None, password=None, **kwargs):
        local_admin = _env("LOCAL_ADMIN_USERNAME", "admin").strip() or "admin"
        if not username or username != local_admin:
            return None

        user = super().authenticate(request, username=username, password=password, **kwargs)
        if user and request is not None:
            profile, _ = PortalUserProfile.objects.get_or_create(user=user)
            profile.last_auth_source = "LOCAL_ADMIN"
            profile.ms_last_login_at = timezone.now()
            profile.ms_user = username
            profile.ms_user_name = username
            profile.ms_status = "LOCAL"
            profile.ms_code_rol = ""
            profile.ms_name_rol = "Administrador"
            profile.ms_result_message = "Login local (admin)"
            profile.save()

            # También poblar sesión para el Dashboard (consistencia visual)
            request.session["ms_user"] = username
            request.session["ms_userName"] = username
            request.session["ms_status"] = "LOCAL"
            request.session["ms_role_code"] = ""
            request.session["ms_role"] = "Administrador"
            request.session["ms_resultMessage"] = "Login local (admin)"
            request.session["ms_token"] = ""

        return user


class MicroserviceBackend:
    """Autenticación contra microservicio para TODOS los usuarios excepto admin local."""

    def authenticate(self, request, username=None, password=None, **kwargs):
        if not username or not password:
            return None

        local_admin = _env("LOCAL_ADMIN_USERNAME", "admin").strip() or "admin"
        if username == local_admin:
            # el admin se valida localmente por LocalAdminBackend
            return None

        # Requisito: el usuario debe existir en el portal
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            if request is not None:
                request.ms_auth_error = "Usuario no existe en el portal. Crea el usuario en /admin/usuarios/."
            return None

        # Bloqueo local (aunque el microservicio lo valide)
        if not user.is_active:
            if request is not None:
                request.ms_auth_error = "Usuario está INACTIVO en el portal."
            return None

        url = _env("MS_LOGIN_URL").strip()
        if not url:
            if request is not None:
                request.ms_auth_error = "MS_LOGIN_URL no está configurada."
            return None

        auth_basic = _normalize_basic(_env("MS_AUTH_BASIC"))
        if not auth_basic or "REPLACE_ME" in auth_basic:
            if request is not None:
                request.ms_auth_error = "MS_AUTH_BASIC no está configurada (Authorization Basic)."
            return None

        headers = {
            "country": _env("MS_COUNTRY", "EC"),
            "lang": _env("MS_LANG", "es"),
            "entity": _env("MS_ENTITY", "OTECEL"),
            "system": _env("MS_SYSTEM", "RPA"),
            "subsystem": _env("MS_SUBSYSTEM", "EPCXXX"),
            "originator": _env("MS_ORIGINATOR", "ms-gateway-generic-portal-huawei"),
            "userId": _env("MS_USERID", "gateway"),
            "operation": "login",
            "destination": _env("MS_DESTINATION", "environment-ms"),
            "execId": str(uuid.uuid4()),
            "msgId": str(uuid.uuid4()),
            "timestamp": _timestamp_value(),
            "msgType": "REQUEST",
            "Authorization": auth_basic,
            "Content-Type": "application/json",
            "pid": str(uuid.uuid4()),
        }

        payload = {"user": username, "password": password, "ip": ""}

        verify_ssl = _env("MS_VERIFY_SSL", "1") == "1"
        timeout = int(_env("MS_TIMEOUT", "15"))

        # Llamada al microservicio
        try:
            # Evitar redirects silenciosos (a veces los gateways redirigen y pueden quitar Authorization)
            resp = requests.post(
                url,
                headers=headers,
                json=payload,
                timeout=timeout,
                verify=verify_ssl,
                allow_redirects=False,
            )

            # Redirect -> error claro
            if 300 <= resp.status_code < 400:
                loc = resp.headers.get("Location", "")
                if request is not None:
                    request.ms_auth_error = f"Microservicio: redirect HTTP {resp.status_code} hacia {loc}. Revisa MS_LOGIN_URL (usa la URL final)."
                return None

            # si viene 4xx/5xx, intentamos leer el body para mostrar mensaje en UI
            if resp.status_code >= 400:
                # Intentar extraer mensaje JSON estándar
                msg = ""
                try:
                    err = resp.json()
                    msg = err.get("exceptionMessage") or err.get("message") or str(err)
                except Exception:
                    msg = (resp.text or "").strip()[:500]

                # fallback a razón HTTP
                if not msg:
                    msg = f"HTTP {resp.status_code} {resp.reason or ''}".strip()

                # Ayuda extra para 401
                if resp.status_code == 401:
                    msg = f"HTTP 401 Unauthorized (revisa MS_AUTH_BASIC y headers)"

                if request is not None:
                    request.ms_auth_error = f"Microservicio: {msg}"
                return None

            data = resp.json()
        except Exception as e:
            if request is not None:
                request.ms_auth_error = f"No fue posible validar con el microservicio: {e}"
            return None

        # Respuesta tipo error (aunque devuelva 200)
        if isinstance(data, dict) and data.get("exceptionCategory"):
            msg = data.get("exceptionMessage") or "Error de microservicio"
            if request is not None:
                request.ms_auth_error = f"Microservicio: {msg}"
            return None

        result_message = (data.get("resultMessage") or "").strip()
        status = (data.get("status") or "").strip().upper()

        # Validación de éxito: status A o mensaje contiene 'Activo'
        ok = (status == "A") or ("activo" in result_message.lower())
        if not ok:
            if request is not None:
                request.ms_auth_error = f"Microservicio: {result_message or 'Usuario no activo'}"
            return None

        # Actualizar perfil con datos del microservicio
        profile, _ = PortalUserProfile.objects.get_or_create(user=user)
        profile.last_auth_source = "MICROSERVICE"
        profile.ms_last_login_at = timezone.now()
        profile.ms_user = (data.get("user") or username) or username
        profile.ms_user_name = (data.get("userName") or data.get("user") or username) or username
        profile.ms_status = status or ""
        profile.ms_code_rol = str(data.get("codeRol") or "").strip()
        profile.ms_name_rol = (data.get("nameRol") or "").strip()
        profile.ms_result_message = result_message
        profile.save()

        # Reglas de admin portal (rol / lista / flag forzado)
        admin_users = {u.strip() for u in _env("ADMIN_USERS", "").split(",") if u.strip()}
        admin_role_codes = {c.strip() for c in _env("ADMIN_ROLE_CODES", "").split(",") if c.strip()}
        code_rol = profile.ms_code_rol

        if profile.force_staff:
            user.is_staff = True
            user.is_superuser = True
        elif (username in admin_users) or (code_rol and code_rol in admin_role_codes):
            user.is_staff = True
            user.is_superuser = True
        else:
            user.is_staff = False
            user.is_superuser = False

        # Asegurar que el password local no se use para usuarios no-admin
        if user.has_usable_password():
            user.set_unusable_password()

        user.save()

        # Sesión para dashboard y consumo posterior (token se queda en sesión)
        if request is not None:
            request.session["ms_user"] = profile.ms_user
            request.session["ms_userName"] = profile.ms_user_name
            request.session["ms_status"] = profile.ms_status
            request.session["ms_role"] = profile.ms_name_rol
            request.session["ms_role_code"] = profile.ms_code_rol
            request.session["ms_resultMessage"] = profile.ms_result_message
            token = data.get("token") or ""
            request.session["ms_token"] = token
            # login() rota la sesión; guardamos también en el request para reinyectar post-login
            request._ms_token = token

        return user

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None
