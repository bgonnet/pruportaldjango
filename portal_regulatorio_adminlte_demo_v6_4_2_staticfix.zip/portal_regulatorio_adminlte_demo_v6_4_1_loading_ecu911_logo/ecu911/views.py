import os
import requests
import xml.etree.ElementTree as ET
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default)

def _build_envelope(numero: str) -> str:
    institucion = _env("ECU911_INSTITUCION", "Prueba")
    usuario = _env("ECU911_USUARIO", "9915e0d72085")
    motivo = _env("ECU911_MOTIVO", "Motivo")
    descripcion = _env("ECU911_DESCRIPCION", "Descripcion")
    return f'''<?xml version="1.0" encoding="utf-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
  <soapenv:Header/>
  <soapenv:Body>
    <tem:ConsultaLocalizacion>
      <tem:Numero>{numero}</tem:Numero>
      <tem:Institucion>{institucion}</tem:Institucion>
      <tem:Usuario>{usuario}</tem:Usuario>
      <tem:Fecha></tem:Fecha>
      <tem:Motivo>{motivo}</tem:Motivo>
      <tem:Descripcion>{descripcion}</tem:Descripcion>
    </tem:ConsultaLocalizacion>
  </soapenv:Body>
</soapenv:Envelope>'''

def _local(tag: str) -> str:
    if not tag:
        return tag
    if "}" in tag:
        return tag.split("}", 1)[1]
    if ":" in tag:
        return tag.split(":", 1)[1]
    return tag

def _extract_consulta_result_fields(xml_raw: str):
    """Return [(Campo, Valor)] for children of ConsultaLocalizacionResult."""
    root = ET.fromstring(xml_raw)
    result_node = None
    for node in root.iter():
        if _local(node.tag) == "ConsultaLocalizacionResult":
            result_node = node
            break

    if result_node is not None:
        fields = []
        for ch in list(result_node):
            k = _local(ch.tag)
            v = (ch.text or "").strip()
            if v != "":
                fields.append((k, v))
        return fields

    # Fallback: last-segment from a flattened walk
    out = []
    def walk(node, path=""):
        p = f"{path}/{_local(node.tag)}" if path else _local(node.tag)
        text = (node.text or "").strip()
        if text:
            out.append((p.split("/")[-1], text))
        for child in list(node):
            walk(child, p)
    walk(root, "")
    seen = set()
    uniq = []
    for k, v in out:
        if (k, v) not in seen:
            uniq.append((k, v))
            seen.add((k, v))
    return uniq

@login_required
def consulta_ecu911(request):
    numero = (request.GET.get("numero") or "").strip()
    xml_raw = ""
    parsed = []
    error = ""

    if numero:
        url = _env("ECU911_URL")
        soap_action = _env("ECU911_SOAP_ACTION", "http://tempuri.org/ConsultaLocalizacion")
        timeout = int(_env("ECU911_TIMEOUT", "60"))

        headers = {"Content-Type": "text/xml; charset=utf-8", "SOAPAction": soap_action}
        body = _build_envelope(numero)

        try:
            resp = requests.post(url, headers=headers, data=body.encode("utf-8"), timeout=timeout)
            resp.raise_for_status()
            xml_raw = resp.text
            parsed = _extract_consulta_result_fields(xml_raw)
        except Exception as e:
            error = str(e)

    return render(request, "ecu911/consulta_ecu911.html", {
        "page_title": "Consulta Ecu 911",
        "numero": numero,
        "xml_raw": xml_raw,
        "parsed": parsed,
        "error": error,
    })
