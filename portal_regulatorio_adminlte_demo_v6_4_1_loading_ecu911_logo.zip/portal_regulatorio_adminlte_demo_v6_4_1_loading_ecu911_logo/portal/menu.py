def get_menu(request):
    is_staff = bool(getattr(getattr(request, "user", None), "is_staff", False))
    menu = [
        {"type": "header", "label": "NAVEGACIÓN"},
        {"type": "item", "label": "Dashboard", "icon": "fas fa-tachometer-alt", "url": "/admin/"},
        {"type": "header", "label": "BI / Servicios"},
        {"type": "item", "label": "Consulta Ecu 911", "icon": "fas fa-phone", "url": "/admin/ecu911/consulta/"},
        {"type": "item", "label": "Consulta BI", "icon": "fas fa-search", "url": "/admin/bi/consulta/"},
        {"type": "item", "label": "Indicadores BI", "icon": "fas fa-chart-line", "url": "/admin/bi/indicadores/"},
        {"type": "header", "label": "ADMINISTRACIÓN"},
        # Solo visible para administradores del portal
        {"type": "item", "label": "Usuarios", "icon": "fas fa-users-cog", "url": "/admin/usuarios/", "staff_only": True},
        {"type": "item", "label": "Cerrar sesión", "icon": "fas fa-sign-out-alt", "url": "/admin/logout/"},
    ]

    if not is_staff:
        menu = [m for m in menu if not m.get("staff_only")]
    return menu
