from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods

from accounts.models import PortalUserProfile


def _populate_ms_session(request, user):
    """Luego de login(), la sesión rota y puede perder variables; poblar aquí."""
    profile, _ = PortalUserProfile.objects.get_or_create(user=user)
    request.session["ms_user"] = profile.ms_user or user.username
    request.session["ms_userName"] = profile.ms_user_name or user.username
    request.session["ms_status"] = profile.ms_status or ""
    request.session["ms_role_code"] = profile.ms_code_rol or ""
    request.session["ms_role"] = profile.ms_name_rol or ""
    request.session["ms_resultMessage"] = profile.ms_result_message or ""
    # ms_token se guarda solo en sesión; no se persiste en BD.
    token = getattr(request, "_ms_token", "") or ""
    if token:
        request.session["ms_token"] = token
    else:
        request.session.setdefault("ms_token", "")


@require_http_methods(["GET", "POST"])
def login_view(request):
    if request.user.is_authenticated:
        return redirect("/admin/")

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            _populate_ms_session(request, user)
            return redirect("/admin/")

        # Mensaje más útil cuando falla el microservicio / usuario no existe / etc.
        err = getattr(request, "ms_auth_error", "") or "Credenciales inválidas o el usuario no está activo."
        messages.error(request, err)

    return render(request, "accounts/login.html")


def logout_view(request):
    logout(request)
    return redirect("/admin/login/")
