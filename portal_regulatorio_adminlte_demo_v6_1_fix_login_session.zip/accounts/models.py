from django.conf import settings
from django.db import models


class PortalUserProfile(models.Model):
    """Preferencias de acceso del portal por usuario.

    NOTA:
    - El login real se hace contra el microservicio (salvo el usuario admin local).
    - Este perfil controla el *rol del portal* (admin/no admin) y permite
      bloquear usuarios aunque el microservicio los valide.
    - También guarda el último resultado relevante del microservicio para
      auditoría/visualización en el portal.
    """

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="portal_profile")
    force_staff = models.BooleanField(
        default=False,
        help_text="Si está activo, este usuario verá el menú de Administración y podrá gestionar usuarios dentro del portal.",
    )
    notes = models.CharField(max_length=255, blank=True, default="")

    # --- Última respuesta del microservicio (login) ---
    last_auth_source = models.CharField(max_length=20, blank=True, default="", help_text="MICROSERVICE o LOCAL_ADMIN")
    ms_last_login_at = models.DateTimeField(null=True, blank=True)

    ms_user = models.CharField(max_length=150, blank=True, default="")
    ms_user_name = models.CharField(max_length=150, blank=True, default="")
    ms_status = models.CharField(max_length=10, blank=True, default="")
    ms_code_rol = models.CharField(max_length=20, blank=True, default="")
    ms_name_rol = models.CharField(max_length=120, blank=True, default="")
    ms_result_message = models.CharField(max_length=255, blank=True, default="")

    class Meta:
        verbose_name = "Portal user profile"
        verbose_name_plural = "Portal user profiles"

    def __str__(self) -> str:  # pragma: no cover
        return f"PortalUserProfile({self.user.username})"
