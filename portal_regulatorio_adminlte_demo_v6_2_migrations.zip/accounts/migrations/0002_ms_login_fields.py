from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("accounts", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="portaluserprofile",
            name="last_auth_source",
            field=models.CharField(blank=True, default="", help_text="MICROSERVICE o LOCAL_ADMIN", max_length=20),
        ),
        migrations.AddField(
            model_name="portaluserprofile",
            name="ms_last_login_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="portaluserprofile",
            name="ms_user",
            field=models.CharField(blank=True, default="", max_length=150),
        ),
        migrations.AddField(
            model_name="portaluserprofile",
            name="ms_user_name",
            field=models.CharField(blank=True, default="", max_length=150),
        ),
        migrations.AddField(
            model_name="portaluserprofile",
            name="ms_status",
            field=models.CharField(blank=True, default="", max_length=10),
        ),
        migrations.AddField(
            model_name="portaluserprofile",
            name="ms_code_rol",
            field=models.CharField(blank=True, default="", max_length=20),
        ),
        migrations.AddField(
            model_name="portaluserprofile",
            name="ms_name_rol",
            field=models.CharField(blank=True, default="", max_length=120),
        ),
        migrations.AddField(
            model_name="portaluserprofile",
            name="ms_result_message",
            field=models.CharField(blank=True, default="", max_length=255),
        ),
    ]
