import os

from django import forms
from django.contrib.auth.models import User

from accounts.models import PortalUserProfile


class PortalUserForm(forms.ModelForm):
    portal_admin = forms.BooleanField(
        required=False,
        label="Admin del portal",
        help_text="Permite ver el menú de Administración y gestionar usuarios dentro del portal.",
        widget=forms.CheckboxInput(attrs={"class": "custom-control-input"}),
    )
    notes = forms.CharField(
        required=False,
        label="Notas",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Opcional"}),
    )

    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "email", "is_active"]
        widgets = {
            "username": forms.TextInput(attrs={"class": "form-control"}),
            "first_name": forms.TextInput(attrs={"class": "form-control"}),
            "last_name": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["is_active"].widget = forms.CheckboxInput(attrs={"class": "custom-control-input"})
        if self.instance and self.instance.pk:
            profile, _ = PortalUserProfile.objects.get_or_create(user=self.instance)
            self.fields["portal_admin"].initial = profile.force_staff
            self.fields["notes"].initial = profile.notes

    def save(self, commit=True):
        user = super().save(commit=False)
        if not user.pk:
            local_admin = os.getenv("LOCAL_ADMIN_USERNAME", "admin")
            if user.username != (local_admin.strip() or "admin"):
                user.set_unusable_password()
        if commit:
            user.save()
            profile, _ = PortalUserProfile.objects.get_or_create(user=user)
            profile.force_staff = bool(self.cleaned_data.get("portal_admin"))
            profile.notes = self.cleaned_data.get("notes") or ""
            profile.save()
        return user


class SetPasswordForm(forms.Form):
    password1 = forms.CharField(label="Nueva contraseña", widget=forms.PasswordInput(attrs={"class": "form-control"}))
    password2 = forms.CharField(label="Confirmar contraseña", widget=forms.PasswordInput(attrs={"class": "form-control"}))

    def clean(self):
        cleaned = super().clean()
        p1 = cleaned.get("password1")
        p2 = cleaned.get("password2")
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return cleaned
