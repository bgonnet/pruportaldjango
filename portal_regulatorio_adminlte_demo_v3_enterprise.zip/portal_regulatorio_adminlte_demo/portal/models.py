from __future__ import annotations

from django.db import models

class BIRecord(models.Model):
    """Registro demo para Consulta BI / Indicadores BI.

    Reemplázalo por tus modelos reales o enlaza a tablas existentes.
    """
    referencia = models.CharField(max_length=64, db_index=True)
    estado = models.CharField(max_length=50, db_index=True)
    fecha = models.DateField(db_index=True)
    descripcion = models.TextField(blank=True, null=True)
    monto = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "bi_record"
        ordering = ["-fecha", "-id"]

    def __str__(self) -> str:
        return f"{self.referencia} ({self.estado})"
