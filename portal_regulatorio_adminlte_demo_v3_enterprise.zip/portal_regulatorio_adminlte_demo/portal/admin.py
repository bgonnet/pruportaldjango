from django.contrib import admin
from .models import BIRecord


@admin.register(BIRecord)
class BIRecordAdmin(admin.ModelAdmin):
    list_display = ("id", "referencia", "estado", "fecha", "monto")
    list_filter = ("estado", "fecha")
    search_fields = ("referencia", "descripcion")
    ordering = ("-fecha", "-id")
