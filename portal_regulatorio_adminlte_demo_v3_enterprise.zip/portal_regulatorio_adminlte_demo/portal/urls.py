from django.urls import path
from . import views

app_name = "portal"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),

    # Nuevas vistas
    path("bi/consulta/", views.consulta_bi, name="consulta_bi"),
    path("ecu911/consulta/", views.consulta_ecu911, name="consulta_ecu911"),
    path("bi/indicadores/", views.indicadores_bi, name="indicadores_bi"),

    # Demos / placeholders
    path("demo/uno/", views.demo_uno, name="demo_uno"),
    path("demo/dos/", views.demo_dos, name="demo_dos"),
    path("ui/<slug:page>/", views.ui_placeholder, name="ui_placeholder"),
]
