from __future__ import annotations

import random
from datetime import date, timedelta

from django.core.management.base import BaseCommand
from portal.models import BIRecord


class Command(BaseCommand):
    help = "Crea registros demo en bi_record para probar Consulta BI / Indicadores BI."

    def add_arguments(self, parser):
        parser.add_argument("--n", type=int, default=100, help="Cantidad de registros a crear (default=100).")
        parser.add_argument("--reset", action="store_true", help="Borra datos existentes antes de cargar.")

    def handle(self, *args, **opts):
        n = opts["n"]
        reset = opts["reset"]

        if reset:
            BIRecord.objects.all().delete()
            self.stdout.write(self.style.WARNING("Se borraron registros existentes."))

        estados = ["OK", "PENDIENTE", "ERROR", "EN_PROCESO"]
        base = date.today()

        created = 0
        for i in range(n):
            BIRecord.objects.create(
                referencia=f"REF-{random.randint(100000, 999999)}",
                estado=random.choice(estados),
                fecha=base - timedelta(days=random.randint(0, 20)),
                descripcion=f"Registro demo #{i+1}",
                monto=round(random.uniform(1, 5000), 2),
            )
            created += 1

        self.stdout.write(self.style.SUCCESS(f"Listo: creados {created} registros demo."))
