from .menu import build_menu

def menu(request):
    return {
        "SIDEBAR_MENU": build_menu(),
    }
