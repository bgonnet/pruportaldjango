from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone

import requests

from xml.etree import ElementTree as ET

from django.db.models import Count, Sum
from django.db.models.functions import TruncDate

from .models import BIRecord

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.views.decorators.http import require_http_methods


@login_required
def dashboard(request):
    return render(request, "portal/dashboard.html")


@login_required
def demo_uno(request):
    return render(request, "portal/demo_uno.html")


@login_required
def demo_dos(request):
    return render(request, "portal/demo_dos.html")


@login_required
def ui_placeholder(request, page):
    # Placeholder pages for showing menu options quickly
    return render(request, "portal/placeholder.html", {"page": page})


@login_required
@require_http_methods(["GET"])
def consulta_bi(request):
    """Consulta BI (ORM real contra Postgres).

    - Filtra por referencia / estado / fecha
    - Renderiza resultados en DataTables (client-side)
    """
    q_ref = (request.GET.get("referencia") or "").strip()
    q_estado = (request.GET.get("estado") or "").strip()
    q_fecha = (request.GET.get("fecha") or "").strip()

    qs = BIRecord.objects.all()

    if q_ref:
        qs = qs.filter(referencia__icontains=q_ref)
    if q_estado:
        qs = qs.filter(estado__icontains=q_estado)
    if q_fecha:
        qs = qs.filter(fecha=q_fecha)  # espera YYYY-MM-DD

    rows = list(qs[:500])

    return render(
        request,
        "portal/consulta_bi.html",
        {
            "q_ref": q_ref,
            "q_estado": q_estado,
            "q_fecha": q_fecha,
            "rows": rows,
        },
    )


def _soap_envelope(numero: str, institucion: str, usuario: str, fecha: str, motivo: str, descripcion: str) -> str:
    # SOAP 1.1 envelope (text/xml + SOAPAction)
    return f"""<?xml version="1.0" encoding="utf-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
  <soapenv:Header/>
  <soapenv:Body>
    <tem:ConsultaLocalizacion>
      <tem:Numero>{numero}</tem:Numero>
      <tem:Institucion>{institucion}</tem:Institucion>
      <tem:Usuario>{usuario}</tem:Usuario>
      <tem:Fecha>{fecha}</tem:Fecha>
      <tem:Motivo>{motivo}</tem:Motivo>
      <tem:Descripcion>{descripcion}</tem:Descripcion>
    </tem:ConsultaLocalizacion>
  </soapenv:Body>
</soapenv:Envelope>"""


@login_required
@require_http_methods(["GET", "POST"])
def _strip_ns(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def _parse_soap_response(xml_text: str) -> dict[str, str]:
    """Parsea SOAP XML y devuelve pares clave/valor (best effort)."""
    data: dict[str, str] = {}
    try:
        root = ET.fromstring(xml_text)
    except Exception:
        return data

    body = root.find(".//{http://schemas.xmlsoap.org/soap/envelope/}Body")
    if body is None:
        body = root.find(".//Body")
    if body is None:
        return data

    response_el = next(iter(body), None)
    if response_el is None:
        return data

    for el in response_el.iter():
        if list(el):
            continue
        txt = (el.text or "").strip()
        if not txt:
            continue
        key = _strip_ns(el.tag)
        if key in data:
            i = 2
            while f"{key}_{i}" in data:
                i += 1
            key = f"{key}_{i}"
        data[key] = txt

    return data


def consulta_ecu911(request):
    """
    Vista demo que consume el servicio SOAP de ECU-911 para ConsultaLocalizacion.
    Si el endpoint no es accesible desde tu PC/red, mostrará un error con el detalle.
    """
    numero = ""
    raw_response = ""
    http_status = None
    error = ""

    # Config por .env
    ecu911_url = os.getenv("ECU911_URL", "http://10.112.162.28:32100/Otecel.WebServices.ECU911V2/Rastreo.asmx")
    soap_action = os.getenv("ECU911_SOAP_ACTION", "http://tempuri.org/ConsultaLocalizacion")
    institucion = os.getenv("ECU911_INSTITUCION", "Prueba")
    usuario = os.getenv("ECU911_USUARIO", "9915e0d72085")
    motivo = os.getenv("ECU911_MOTIVO", "Motivo")
    descripcion = os.getenv("ECU911_DESCRIPCION", "Descripcion")
    timeout_sec = int(os.getenv("ECU911_TIMEOUT", "15"))

    if request.method == "POST":
        numero = (request.POST.get("numero") or "").strip()
        if not numero:
            messages.error(request, "Ingresa un número de teléfono.")
        else:
            # Fecha opcional (ISO); si lo dejas vacío, el servicio decidirá qué hacer
            fecha = (request.POST.get("fecha") or "").strip()
            envelope = _soap_envelope(numero, institucion, usuario, fecha, motivo, descripcion)

            headers = {
                "Content-Type": "text/xml; charset=utf-8",
                "SOAPAction": soap_action,
                # Trazabilidad útil
                "execId": str(uuid.uuid4()),
                "msgId": str(uuid.uuid4()),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            try:
                resp = requests.post(ecu911_url, data=envelope.encode("utf-8"), headers=headers, timeout=timeout_sec)
                http_status = resp.status_code
                raw_response = resp.text
                parsed_data = _parse_soap_response(raw_response)
                if resp.ok:
                    messages.success(request, f"Consulta realizada. HTTP {resp.status_code}.")
                else:
                    messages.error(request, f"El servicio respondió con error HTTP {resp.status_code}.")
            except requests.RequestException as ex:
                error = str(ex)
                messages.error(request, "No se pudo conectar al servicio ECU-911 (ver detalle abajo).")

    return render(
        request,
        "portal/consulta_ecu911.html",
        {
            "numero": numero,
            "ecu911_url": ecu911_url,
            "http_status": http_status,
            "raw_response": raw_response,
            "parsed_data": parsed_data,
            "error": error,
        },
    )


@login_required
@require_http_methods(["GET"])
def indicadores_bi(request):
    """Indicadores BI con ejemplos de gráficos (Chart.js) basados en bi_record."""

    qs = BIRecord.objects.all()

    daily = (
        qs.annotate(d=TruncDate("fecha"))
        .values("d")
        .annotate(c=Count("id"), s=Sum("monto"))
        .order_by("d")
    )

    labels = []
    serie_count = []
    serie_sum = []

    for r in daily:
        if r["d"] is None:
            continue
        labels.append(r["d"].strftime("%a %d"))
        serie_count.append(int(r["c"] or 0))
        serie_sum.append(float(r["s"] or 0))

    if not labels:
        labels = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
        serie_count = [12, 19, 3, 5, 2, 3, 9]
        serie_sum = [1200, 900, 300, 450, 200, 700, 980]

    by_estado = qs.values("estado").annotate(c=Count("id")).order_by("-c")[:6]
    donut_labels = [x["estado"] or "N/A" for x in by_estado]
    donut_values = [int(x["c"] or 0) for x in by_estado]
    if not donut_labels:
        donut_labels = ["OK", "PENDIENTE", "ERROR"]
        donut_values = [60, 25, 15]

    return render(
        request,
        "portal/indicadores_bi.html",
        {
            "labels": labels,
            "serie1": serie_count,
            "serie2": serie_sum,
            "donut_labels": donut_labels,
            "donut_values": donut_values,
        },
    )


