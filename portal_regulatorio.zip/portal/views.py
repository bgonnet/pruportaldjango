from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from accounts.models import PortalUserProfile


@login_required
def dashboard(request):
    profile, _ = PortalUserProfile.objects.get_or_create(user=request.user)
    return render(
        request,
        "portal/dashboard.html",
        {
            "page_title": "Dashboard",
            "profile": profile,
        },
    )
