from django.apps import AppConfig

class Ecu911Config(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "ecu911"
