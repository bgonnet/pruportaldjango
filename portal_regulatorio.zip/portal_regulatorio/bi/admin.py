from django.contrib import admin
from .models import BIRecord

@admin.register(BIRecord)
class BIRecordAdmin(admin.ModelAdmin):
    list_display = ("referencia", "estado", "categoria", "fecha", "valor")
    search_fields = ("referencia", "estado", "categoria")
    list_filter = ("estado", "categoria", "fecha")
