from django.db import models

class BIRecord(models.Model):
    referencia = models.CharField(max_length=64, db_index=True)
    estado = models.CharField(max_length=20, db_index=True)
    categoria = models.CharField(max_length=30, db_index=True, default="General")
    fecha = models.DateField(db_index=True)
    valor = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.referencia} - {self.estado} - {self.fecha}"
