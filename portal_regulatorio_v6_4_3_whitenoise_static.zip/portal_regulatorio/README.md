# Portal Regulatorio - Demo AdminLTE v3 + Django (v5)

## Portal
- **Portal AdminLTE (UI completa):** http://127.0.0.1:8000/admin/
- **Login:** http://127.0.0.1:8000/admin/login/
- **Gestión de usuarios (look AdminLTE):** http://127.0.0.1:8000/admin/usuarios/

## Setup
```bash
python -m venv .venv
# Windows: .\.venv\Scripts\activate
pip install -r requirements.txt
# Copia .env.example a .env y ajusta MS_AUTH_BASIC + DATABASE_URL
python manage.py migrate
python manage.py seed_bi --reset --n 150
python manage.py runserver

# Importante: si ya tenías DB creada, aplica migraciones nuevas:
# python manage.py migrate
```

## Login
- Ir a: http://127.0.0.1:8000/admin/login/
- Autentica contra MS_LOGIN_URL (Movistar PRE)

## ECU911
- Requiere conectividad a la IP 10.112.162.28 (intranet).
